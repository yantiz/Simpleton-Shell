#!/bin/bash

# test cat and --creat/--append/--trunc
echo "this is test case 1" > data/test_in1
./simpsh --rdonly data/test_in1 --creat --trunc --wronly data/test_out1 --creat --append --wronly data/test_err1 --command 0 1 2 cat

# test stderr by invoking cp without argument
./simpsh --rdonly /dev/null --creat --trunc --wronly data/test_out2 --creat --append --wronly data/test_err2 --command 0 1 2 cp

# test pipe and profile
./simpsh --rdonly simpsh.c --creat --trunc --wronly data/test_out3 --creat --append --wronly data/test_err3 --pipe \
	 --command 0 4 2 cat --command 3 1 2 cat - --profile
