#!/bin/bash

# test cat
echo "this is a test file" > data/test_in1
touch data/test_out1 data/test_err1
./simpsh --rdonly data/test_in1 --wronly data/test_out1 --rdwr data/test_err1 --command 0 1 2 cat --wait

# test ls
touch data/test_out2
./simpsh --rdonly /dev/null --wronly data/test_out2 --rdwr /dev/null --command 0 1 2 ls -l -a --wait

# test cat and ls and verbose
echo "this is another test file" > data/test_in3
touch data/test_out3
./simpsh --verbose --rdonly data/test_in1 --wronly data/test_out3 --rdwr /dev/null --command 0 2 2 cat --command 2 1 2 ls -l --wait

# test pipe and profile
./simpsh --rdonly simpsh.c --creat --wronly data/test_out4 --rdwr /dev/null --pipe --command 0 4 2 cat --command 3 1 2 grep stderr --wait --profile
