#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <wait.h>
#include <sys/time.h>
#include <sys/resource.h>

#define MAX_FDS 1024
#define MAX_ARGV_NUM 1024
#define MAX_PROC_NUM 1024

// store all opts
char *OPTS[] = {
    "--append",
    "--cloexec",
    "--creat",
    "--directory",
    "--dsync",
    "--excl",
    "--nofollow",
    "--nonblock",
    "--rsync",
    "--sync",
    "--trunc",
    "--rdonly",
    "--rdwr",
    "--wronly",
    "--pipe",
    "--command",
    "--wait",
    "--verbose",
    "--profile",
    "--abort",
    "--catch",
    "--ignore",
    "--default",
    "--pause",
};

/**
 *  store child process info
 */
typedef struct {
    int pid;
    char *cmd_argv[MAX_ARGV_NUM];
    int cmd_argv_len;
    int status;
} proc_info;


/**
 * Judge if str is a opt, return 1 if true else return 0
 */
int is_opt(char *str) {
    int i = 0;
    for (i = 0; i < (int)(sizeof(OPTS) / sizeof(OPTS[0])); i++) {
        if (strcmp(str, OPTS[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

/**
 * signal handler
 */
void catch(int sig) {
    fprintf(stderr, "signal: %d\n", sig);
    exit(sig);
}

int main(int argc, char *argv[])
{
    /* Parse argv directly is more simple than use getopt_long */

    // Indicate verbose
    int verbose = 0;

    // save file open flags, need clear after open
    int open_flags = 0;

    // store all file descriptors
    int fds[MAX_FDS];
    int fds_len = 0;

    // store all child processes
    proc_info *procs = calloc(MAX_PROC_NUM, sizeof(proc_info));
    int procs_len = 0;

    // indicate if error happend
    int error = 0;

    int argc_n = 0;
    int i = 0, j = 0;
    for (argc_n = 0; argc_n < argc; argc_n++) {
        if (strcmp(argv[argc_n], "--verbose") == 0) {
            // verbose opt, set verbose flag and print this opt
            verbose = 1;
            continue;
        }
        if (strcmp(argv[argc_n], "--append") == 0) {
            if (verbose) printf("%s ", argv[argc_n]);
            open_flags |= O_APPEND;
            continue;
              
        }
        if (strcmp(argv[argc_n], "--cloexec") == 0) {
            if (verbose) printf("%s ", argv[argc_n]);
            open_flags |= O_CLOEXEC;
            continue;
        }
        if (strcmp(argv[argc_n], "--creat") == 0) {
            if (verbose) printf("%s ", argv[argc_n]);
            open_flags |= O_CREAT;
            continue;
        }
        if (strcmp(argv[argc_n], "--directory") == 0) {
            if (verbose) printf("%s ", argv[argc_n]);
            open_flags |= O_DIRECTORY;
            continue;
        }
        if (strcmp(argv[argc_n], "--dsync") == 0) {
            if (verbose) printf("%s ", argv[argc_n]);
            open_flags |= O_DSYNC;
            continue;
        }
        if (strcmp(argv[argc_n], "--excl") == 0) {
            if (verbose) printf("%s ", argv[argc_n]);
            open_flags |= O_EXCL;
            continue;
        }
        if (strcmp(argv[argc_n], "--nofollow") == 0) {
            if (verbose) printf("%s ", argv[argc_n]);
            open_flags |= O_NOFOLLOW;
            continue;
        }
        if (strcmp(argv[argc_n], "--nonblock") == 0) {
            if (verbose) printf("%s ", argv[argc_n]);
            open_flags |= O_NONBLOCK;
            continue;
        }
        if (strcmp(argv[argc_n], "--rsync") == 0) {
            if (verbose) printf("%s ", argv[argc_n]);
            open_flags |= O_RSYNC;
            continue;
        }
        if (strcmp(argv[argc_n], "--sync") == 0) {
            if (verbose) printf("%s ", argv[argc_n]);
            open_flags |= O_SYNC;
            continue;
        }
        if (strcmp(argv[argc_n], "--trunc") == 0) {
            if (verbose) printf("%s ", argv[argc_n]);
            open_flags |= O_TRUNC;
            continue;
        }
        if (strcmp(argv[argc_n], "--rdonly") == 0
            || strcmp(argv[argc_n], "--rdwr") == 0
            || strcmp(argv[argc_n], "--wronly") == 0) {
            // need open file
            if (strcmp(argv[argc_n], "--rdonly") == 0) {
                open_flags |= O_RDONLY;
            } else if (strcmp(argv[argc_n], "--rdwr") == 0) {
                open_flags |= O_RDWR;
            } else {
                open_flags |= O_WRONLY;
            }
            if (argc_n + 1 >= argc || is_opt(argv[argc_n + 1])) {
                // no file name
                fprintf(stderr, "file name not found after %s\n", argv[argc_n]);
                error = 1;
                continue;
            }
            if (verbose) printf("%s %s\n", argv[argc_n], argv[argc_n + 1]);
            // open file, argv[argc_n+1] if filename
            int fd = open(argv[argc_n + 1], open_flags, S_IRUSR | S_IWUSR);
            if (fd < 0) {
                fprintf(stderr, "open file failed %s: %s\n", argv[argc_n + 1], strerror(errno));
                error = 1;
            } else {
                // append fd into fds
                fds[fds_len++] = fd;
            }
            // after open file, clear flags
            open_flags = 0;
            // skip filename
            argc_n++;
            continue;
        }
        if (strcmp(argv[argc_n], "--pipe") == 0) {
            // create pipe and append into fds
            int pfds[2];
            pipe(pfds);
            fds[fds_len++] = pfds[0];
            fds[fds_len++] = pfds[1];
            continue;
        }
        if (strcmp(argv[argc_n], "--command") == 0) {
            // --command i o e cmd args
            int t = 1;
            while (argc_n + t < argc && is_opt(argv[argc_n + t]) == 0) {
                t++;
            }
            if (t < 5) {
                // must have 5 args
                fprintf(stderr, "command invalid\n");
                error = 1;
                argc_n += t - 1;
                continue;
            }
            // get i o e
            int ifd = atoi(argv[argc_n + 1]);
            int ofd = atoi(argv[argc_n + 2]);
            int efd = atoi(argv[argc_n + 3]);
            // if i o e not in fds, error
            if (ifd >= fds_len || ofd >= fds_len || efd >= fds_len) {
                fprintf(stderr, "i o e invalid\n");
                error = 1;
                argc_n += t - 1;
                continue;
            }

            if (verbose) {
                printf("--command %s %s %s", argv[argc_n + 1], argv[argc_n + 2], argv[argc_n + 3]);
            }
            // save argv in proc
            proc_info proc;
            proc.cmd_argv_len = 0;
            for (i = 4; i < t; i++) {
                proc.cmd_argv[proc.cmd_argv_len++] = argv[argc_n + i];
                if (verbose) {
                    printf(" %s", argv[argc_n + i]);
                }
            }
            proc.cmd_argv[proc.cmd_argv_len] = NULL;
            if (verbose) {
                printf("\n");
            }
            // execute command use execpv
            int pid = fork();
            if (pid < 0) {
                fprintf(stderr, "fork failed: %s\n", strerror(errno));
                error = 1;
            } else if (pid == 0) {
                // child process
                // redirect ios
                for (i = 0; i < fds_len; i++) {
                    // close unused fd
                    if (i != ifd && i != ofd && i != efd) {
                        close(fds[i]);
                    }
                }
                // dup stdin stdout stderr
                dup2(fds[ifd], 0);
                dup2(fds[ofd], 1);
                dup2(fds[efd], 2);
                int ret = execvp(proc.cmd_argv[0], proc.cmd_argv);
                if (ret != 0) {
                    fprintf(stderr, "ececvp failed: %s\n", strerror(errno));
                }
                return errno;
            } else {
                // parent process
                proc.pid = pid;
                proc.status = 0;
                procs[procs_len++] = proc;
            }
            argc_n += t - 1;
            continue;
        }
        if (strcmp(argv[argc_n], "--wait") == 0) {
            if (verbose) {
                printf("--wait\n");
            }
            // before wait, parent child should close all fds(or pipes will not work)
            for (i = 0; i < fds_len; i++) {
                if (fds[i] >= 0) {
                    close(fds[i]);
                    fds[i] = -1;
                }
            }
            for (i = 0; i < procs_len; i++) {
                // wait each child process, and report status and cmd
                waitpid(procs[i].pid, &procs[i].status, 0);
                printf("%d", WEXITSTATUS(procs[i].status));
                for (j = 0; j < procs[i].cmd_argv_len; j++) {
                    printf(" %s", procs[i].cmd_argv[j]);
                }
                printf("\n");
            }
            continue;
        }
        if (strcmp(argv[argc_n], "--profile") == 0) {
            if (verbose) printf("%s\n", argv[argc_n]);
            struct rusage usage;
            getrusage(RUSAGE_CHILDREN, &usage);
            printf("ru_utime=%ldus ru_stime=%ldus ru_maxrss=%ld ru_ixrss=%ld ru_idrss=%ld "
                    "ru_isrss=%ld ru_minflt=%ld ru_majflt=%ld ru_nswap=%ld ru_inblock=%ld "
                    "ru_oublock=%ld ru_msgsnd=%ld ru_msgrcv=%ld ru_nsignals=%ld ru_nvcsw=%ld "
                    "ru_nivcsw=%ld\n", usage.ru_utime.tv_sec*1000000+usage.ru_utime.tv_usec,
                    usage.ru_stime.tv_sec*1000000+usage.ru_stime.tv_usec, usage.ru_maxrss,
                    usage.ru_ixrss, usage.ru_idrss, usage.ru_isrss, usage.ru_minflt, usage.ru_majflt,
                    usage.ru_nswap, usage.ru_inblock, usage.ru_oublock, usage.ru_msgsnd, usage.ru_msgrcv,
                    usage.ru_nsignals, usage.ru_nvcsw, usage.ru_nivcsw);
            continue;
        }
        if (strcmp(argv[argc_n], "--abort") == 0) {
            if (verbose) printf("%s\n", argv[argc_n]);
            abort();
            continue;
        }
        if (strcmp(argv[argc_n], "--catch") == 0) {
            if (argc_n + 1 >= argc || is_opt(argv[argc_n + 1])) {
                // no signal
                fprintf(stderr, "signal not found after %s\n", argv[argc_n]);
                continue;
            }
            if (verbose) printf("%s %s\n", argv[argc_n], argv[argc_n + 1]);
            signal(atoi(argv[argc_n + 1]), catch);
            argc_n++;
            continue;
        }
        if (strcmp(argv[argc_n], "--ignore") == 0) {
            if (argc_n + 1 >= argc || is_opt(argv[argc_n + 1])) {
                // no signal
                fprintf(stderr, "signal not found after %s\n", argv[argc_n]);
                continue;
            }
            if (verbose) printf("%s %s\n", argv[argc_n], argv[argc_n + 1]);
            signal(atoi(argv[argc_n + 1]), SIG_IGN);
            argc_n++;
            continue;
        }
        if (strcmp(argv[argc_n], "--default") == 0) {
            if (argc_n + 1 >= argc || is_opt(argv[argc_n + 1])) {
                // no signal
                fprintf(stderr, "signal not found after %s\n", argv[argc_n]);
                continue;
            }
            if (verbose) printf("%s %s\n", argv[argc_n], argv[argc_n + 1]);
            signal(atoi(argv[argc_n + 1]), SIG_IGN);
            argc_n++;
            continue;
        }
        if (strcmp(argv[argc_n], "--pause") == 0) {
            if (verbose) printf("%s\n", argv[argc_n]);
            pause();
            continue;
        }
    }
    // parent child should close all fds(or pipes will not work)
    for (i = 0; i < fds_len; i++) {
        if (fds[i] >= 0) {
            close(fds[i]);
            fds[i] = -1;
        }
    }
    // get the max status
    int max_status = 0;
    for (i = 0; i < procs_len; i++) {
        if (procs[i].status > max_status) {
            max_status = WEXITSTATUS(procs[i].status);
        }
    }
    free(procs);
    // if error happend and max_stats is 0, return 1
    if (max_status == 0 && error) {
        max_status = 1;
    }
    return max_status;
}
